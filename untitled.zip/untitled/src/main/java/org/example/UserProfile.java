package org.example;

public class UserProfile {
    private String name;

    // Constructor
    public UserProfile(String name) {
        this.name = name;
    }

    // Getter cho tên
    public String getName() {
        return name;
    }
}
