package org.example;

public class Multiply {
    public static int multiply(int a, int b) {
        return a * b;
    }
}